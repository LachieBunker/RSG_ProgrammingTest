This a clone of Breakout, developed for a test for RealSeriousGames.
When the ball hits the paddle, the bounce angle is based on where on the paddle the ball hit.
If the ball hits the edges, it will bounce at a low angle, if it hits the middle, the ball will bounce at a steep angle.
The purple bricks are special bricks, and spawn an extra ball when destroyed.
To import a custom brick layout, enter a custom 10-digit number in the BrickLayouts/BrickLayout.txt file